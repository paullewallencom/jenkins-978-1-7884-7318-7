# Effective-Jenkins-Improving-Quality-in-the-Delivery-Pipeline-with-Jenkins
Effective Jenkins: Improving Quality in the Delivery Pipeline with Jenkins [video], published by Packt
